package KAKAO_API.projected.api.login.repository;

public class LoginRepository {
}
