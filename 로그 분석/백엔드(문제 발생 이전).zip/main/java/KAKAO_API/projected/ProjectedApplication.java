package KAKAO_API.projected;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectedApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectedApplication.class, args);
	}

}
